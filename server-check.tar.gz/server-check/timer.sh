#!/bin/bash

nohup python timer.py > ~/data/logs/timer.out &
