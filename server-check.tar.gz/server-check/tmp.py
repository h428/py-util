import math

print(math.ceil(0.001))